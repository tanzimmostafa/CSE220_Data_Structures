public class Node{
  public int key;
  public Node next;
  
  public Node(int v,Node n){
   key=v;
   next=n;
  }
}