public class p2Task2{
  public static void main(String[] args){
   int a=1/0;
}
}
//Note- Error: ArithmeticException