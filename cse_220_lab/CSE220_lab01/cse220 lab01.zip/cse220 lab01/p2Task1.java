public class p2Task1{
  public static void main(String[] args){
  int [] a=new int[5];
  a[21]=100;
}
}
//Note- Error: ArrayIndexOutOfBoundsException