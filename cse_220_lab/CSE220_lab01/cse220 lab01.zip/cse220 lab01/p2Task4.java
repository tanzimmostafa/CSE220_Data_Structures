import java.util.Scanner;
public class p2Task4{
 public static void main(String[]args){
      try{  
      Scanner sc=new Scanner(System.in);
        int x,n=sc.nextInt();
        int a[]=new int[n];
        a[5]=99;
        x=n/0;
      }
      catch(ArithmeticException a){
       System.out.println("Don't divide by zero");
      }
      catch(ArrayIndexOutOfBoundsException b){
       System.out.println("Give length of array more than 5!! ");     
      }
      catch(Exception a){
       System.out.println("Please try again");
      }
      finally{
       System.out.println("THE END");
      }
    }
}

      
      
      
      