public class StackUnderflowException extends Exception{
  public String toString(){
    return "StackUnderflowException";  
  }
}