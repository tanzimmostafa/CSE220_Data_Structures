public class Node2{
  public int element;
  public Node2 next;
  public Node2 prev;
  
  public Node2(int e,Node2 n,Node2 p){
    element =e ;
    next = n;
    prev =p;
    
  }
}