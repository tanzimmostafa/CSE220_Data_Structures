public class Node{
  public int val;
  public Node next;
  
  public Node(int e, Node n){
    val =e ;
    next = n;
    
  }
  
}