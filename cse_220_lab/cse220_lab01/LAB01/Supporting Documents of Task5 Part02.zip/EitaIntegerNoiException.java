// do not modify this file
public class EitaIntegerNoiException extends Exception
{
    
}