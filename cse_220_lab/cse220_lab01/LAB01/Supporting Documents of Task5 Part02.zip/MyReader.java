import java.util.*;
public class MyReader{
    //modify following line so that this method can throw Exception
    int readInteger( ) {
        Scanner k = new Scanner(System.in);
      
        int answer;
       
        String s;
        if (s contains(".")){
         
        }else{    
          
        }
        
    }
}