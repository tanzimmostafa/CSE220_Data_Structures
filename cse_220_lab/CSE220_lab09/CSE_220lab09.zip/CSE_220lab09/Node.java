public class Node{
 int val;
 Node next;
 Node(int a,Node n){
  val=a;
  next=n;
 }
}